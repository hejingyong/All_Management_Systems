#include "SqList.h"
#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string.h>
using namespace std;

//��ʼ��
Status InitBook(SqList &L)
{
	L.elem = new ElemType[MAXSIZE];
	if (!L.elem) exit(OVERFLOW);
	L.length = 0;
	return OK;
}

//��ȡ�ļ�
Status ReadFile(SqList &L)
{
	char buf[0xFF];
	int len;
	ifstream in("book.txt");
	if(!in) {
		cerr << "open file fail!" << endl;
		return ERROR;
		
	} 
 	string line;

 	const char *sep = " ";
 	char *p[4];
 	char *s;
 	int i ;
 	len = 0;
    while(getline(in,line))
    {   
    	if (line != "") {
		
     	i = 0;
		s = (char *)line.c_str();
  		p[0]= strtok(s, sep);
  		while(p[i] != NULL)
  		{
  			i++;
  			p[i] = strtok(NULL, sep);
		}
		p[i] = "\0";
    	strcpy(L.elem[len].ISBN,p[0]);
		strcpy(L.elem[len].name,p[1]);
		L.elem[len].price = atof(p[2]);
		len++;
		L.length++;	
	}
		
	}
	
	cout << "OK" << endl; 
	in.close(); 
		
	
		
}
//��ʾ����ͼ����Ϣ
void ShowBook(SqList L)
{
	int i;
	for (i = 0; i < L.length; i++)
		cout << "ISBN:" << L.elem[i].ISBN << "\t����:" << L.elem[i].name <<"\t�۸�:" << L.elem[i].price << endl;	
}

//ͳ��ͼ�����
void CountBook(SqList L)
{
	cout << "ͼ�����:"  << L.length << endl;	
}

//ͼ����߼۸�
void ShowHighPrice(SqList L)
{
	int i;
	int imax = L.elem[0].price;  
	for (i = 1; i < L.length; i++)
	{
		if (L.elem[i].price > imax)
			imax = i;
	}
	cout << "��߼۸�:"<< endl;
	cout << "ISBN:" << L.elem[imax].ISBN << "\t����:" << L.elem[imax].name <<"\t�۸�:" << L.elem[imax].price << endl;	
	
}
//ͼ��ƽ���۸�
void ShowAveragePrice(SqList L)
{	
	int i;
	double sum = 0.0;
	for (i = 0; i < L.length; i++)
	{
	  sum += L.elem[i].price;
	}
	cout << "ƽ���۸�:" << sum / L.length << endl; 
}
//����������
Status FindBookByName(SqList L,char *inName,char *outISBN,char* outName)
{
	int i;
	for (i = 0; i < L.length; i++) 
			if (strcmp(L.elem[i].name,inName))
			{
				strcpy(outISBN,L.elem[i].ISBN);
				strcpy(outName,L.elem[i].name);
				return OK;
				
			}
	return ERROR;

}
//��ȡͼ��
Status GetBook(SqList L,int i,ElemType &e)
{
	if (i < 1 || i > L.length) return ERROR;
		e = L.elem[i];
	return OK;

}
//���벢д���ļ�
Status InsertBook(SqList &L,int i ,ElemType e)
{
	int j;
	ofstream out("book.txt",ios::out);
	if(!out) {
		cerr << "open file fail!" << endl;
		return ERROR;
	}
	if (i < 1 || i > L.length+1) return ERROR;
	for(j = L.length-1;j >= i -1; j--)
		L.elem[j+1] = L.elem[j];
		L.elem[i-1] =  e;
		++L.length;
	//out.write((char *)L.elem,sizeof(ElemType)*L.length);
    int k;
	for (k = 0; k < L.length; k++)
	{ 
		out << L.elem[k].ISBN << " " << L.elem[k].name << " " << L.elem[k].price << endl;
		
	}
	out.close();
	cout << "OK" << endl; 
		return OK; 
}
//ɾ��ͼ��
Status DeleteBooK(SqList &L, int i)
{
	int j;
	if (i < 1 || i > L.length) return ERROR;
	for( j =1 ; j <= L.length-1;j++)
		L.elem[j-1] = L.elem[j]; 
	--L.length;
	return OK;	
}
//����洢
Status Inverse(SqList L)
{	
	ofstream out("book_inverse.txt",ios::out);
	if(!out) {
		cerr << "open file fail!" << endl;
		return ERROR;
	}
	    int k;
	for (k = L.length-1; k > -1; k--)
	{  
		out << L.elem[k].ISBN << " " << L.elem[k].name << " "<< L.elem[k].price << endl;
		
	}
	out.close();
	cout << "OK" << endl; 
	return OK; 
	
}


 
