#include "User.h"

struct _User *ask_user_info()
{
    struct _User *user;

    user = (struct _User*)malloc(sizeof(struct _User));
    if (user == NULL) {
        perror("malloc");
        exit(EXIT_FAILURE);
    }

    puts("����������:");
    scanf("%s", user->name);
    puts("����ѧ����:");
    scanf("%s", user->id);
    puts("���������� 0:)��ʦ, 1:)ѧ��:");
    scanf("%d", &user->type);

    return user;
}
 
void init_teacher(struct _User *p)
{
    p->max_num_borrow = 15;
    p->max_time_borrow = 180;
}

void init_student(struct _User *p)
{
    p->max_time_borrow = 10;
    p->max_time_borrow = 120;
}


