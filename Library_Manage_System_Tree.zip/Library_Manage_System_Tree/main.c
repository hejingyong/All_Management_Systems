/*************************************************************************
	> File Name: main.c
	> Author: YazongMa
	> Mail: mayazong@126.com
	> Created Time: 2017��04��19�� 16:51:57
 ************************************************************************/

#include <stdio.h>
// #include <vld.h>
#include <string.h>
#include <stdlib.h>

#include "BinaryTree.h"
#include "User.h"

#include <time.h>


typedef struct _BookInfo BookInfo;

void welcome();
int main ()
{
	
	int input;
	TreeNodePtr T,P;
	struct _User *user;
	InitTree(&T);
    while (1) {
        welcome();
        puts("");
        puts("�������ѡ��:");
        scanf("%d", &input);

        switch (input) {
            case 1:
                // ����ͼ��
                BookInfo *book_info;
                user = ask_user_info();
                if (user->type != 0) {
                    printf("ѧ����������ͼ��\n");
                    free(book_info);
                    book_info = NULL;
                    break;
                }
			    book_info = (BookInfo *)malloc(sizeof (struct _BookInfo));
			    if (book_info == NULL) {
			        perror("malloc");
			        exit(EXIT_FAILURE);
			    }
			    puts("�����鱾id:");
			    scanf("%d", &book_info->id);
			    puts("�����鱾����:");
			    scanf("%s", book_info->name);
			    puts("�����鱾����:");
			    scanf("%s", book_info->author_name);
			    puts("");
                InsertTree(&T,*book_info);
                InOrderTraverse(T);
                free(book_info);
                book_info = NULL;
                free(book_info);
                book_info = NULL;
                              
                break;
            case 2:
                // ɾ��ͼ��
                int book_id;
                user = ask_user_info();
                if (user->type != 0) {
                    printf("ѧ������ɾ��ͼ��\n");
                    free(book_info);
                    book_info = NULL;
                    break;
                }
                puts("�����鱾id:");
                scanf("%d", &book_id);
                DeleteNode(&T, book_id);
                InOrderTraverse(T);
                free(book_info);
                book_info = NULL;
                break;
            case 3:
                // �޸�ͼ��
                user = ask_user_info();
                if (user->type != 0) {
                    printf("ѧ�������޸�ͼ��\n");
                    free(book_info);
                    book_info = NULL;
                    break;
                }
			    book_info = (BookInfo *)malloc(sizeof (struct _BookInfo));
			    puts("�����鱾id:");
			    scanf("%d", &book_info->id);
			    puts("�����鱾����:");
			    scanf("%s", book_info->name);
			    puts("�����鱾����:");
			    scanf("%s", book_info->author_name);
			    puts("");
			    P = FindElem(T, *book_info);
                if(P)
                {
                	P->data.id = book_info->id;
                	strncpy(P->data.author_name,book_info->author_name,MAXNAME);
					strncpy(P->data.name,book_info->name,MAXNAME);
					InOrderTraverse(T);
                	puts("�޸ĳɹ�!");
				}
				else
				{
					puts("�޸�ʧ��!"); 
				}
				free(book_info);
                book_info = NULL;
                free(book_info);
                book_info = NULL;
				
            case 4:
            	{ 
                // ��ѯͼ��
                book_info = (BookInfo *)malloc(sizeof (struct _BookInfo));
			    puts("�����鱾id:");
			    scanf("%d", &book_info->id);
			    P = FindElem(T, *book_info);
                if(P)
                {
                	
                	printf("ͼ���ID:%d\n",P->data.id);
                	printf("ͼ�������:%s\n",P->data.author_name);
                	printf("ͼ�������:%s\n",P->data.name);
                	puts("��ѯ�ɹ�!");
				}
				else
				{
					puts("��ѯʧ��!"); 
				}
				free(book_info);
                book_info = NULL;

            case 5:
            	// ����
                break;
            case 6:
            	// ����
                break;
            case 7:
            	//�鿴�û���Ϣ
                break;
            case 8:
            	// ͳ��
                // statistic();
                exit(EXIT_SUCCESS);
            case 9:
            	//�鿴ʣ��ͼ��
                break;
            case 10:
                exit(EXIT_SUCCESS);
            default:
                puts("�������");
                break;
        }
    }
}
}


void welcome()
{
    puts("-------------------");
    puts("��ӭʹ��ͼ�����ϵͳ");
    puts("1:) ����һ��ͼ��");
    puts("2:) ɾ��һ��ͼ��");
    puts("3:) �޸�һ��ͼ��");
    puts("4:) ��ѯһ��ͼ��");
    puts("5:) ����");
    puts("6:) ����");
    puts("7:) �鿴�û���Ϣ");
    puts("8:) ͳ��");
    puts("9:) �鿴ʣ��ͼ��");
    puts("10:) �˳�");
    puts("-------------------");
    puts("");
}
