#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define MAXNAME 254
#define MAXBUF 1024
#define MAXBOOK 100

struct _User {
    char id[4];
    char name[MAXNAME];
    int num_borrow;
    // time_t time_borrow;
    // time_t time_return;
    int time_borrow;
    int time_return;
    int max_num_borrow;
    int max_time_borrow;
    int borrowed_bookid;
    char borrowed_bookname[MAXNAME];
    enum { TEACHER, STUDENT } type;
};
//�ж���ʦ����ѧ�� 
struct _User *ask_user_info(); 

//��ʼ�������������ʱ�� 
void init_teacher(struct _User *p);
void init_student(struct _User *p);

 



